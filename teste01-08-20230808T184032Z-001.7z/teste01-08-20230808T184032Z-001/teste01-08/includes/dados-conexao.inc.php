<?php
 $servidor = "localhost";
 $usuario  = "root";
 $senha    = "";
 $nomeDoBanco = "test2";
 $nomeDaTabela1 = "espaco";
 $nomeDaTabela2 = "horario";
 $nomeDaTabela3 = "reservas";
 $nomeDaTabela4 = "usuario";
 $nomeDaTabela5 = "reserva";